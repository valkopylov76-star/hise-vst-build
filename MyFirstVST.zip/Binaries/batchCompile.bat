@echo off
set project=MyFirstVST
set build_path=C:\MyFirstVST\Binaries

:: ���� � ������ �������������� HISE � JUCE
set HISE_PATH=C:\Program Files\VSTPlugIns\Sampler\HISE\HISE-2.0.0
set JUCE_PATH=C:\Program Files\VSTPlugIns\Sampler\HISE\HISE-2.0.0\JUCE

:: ������ ���������� ��� ����� ���������� GCC 8.1.0
set PATH=C:\mingw32\bin;%PATH%

echo ===================================================
echo   STEP 1: COMPILING INDIVIDUAL OBJECTS (LOW MEMORY)
echo ===================================================

cd /d "%build_path%"
if exist mingw_error.txt del mingw_error.txt

:: ����������� ����� ����������
set FLG=-std=c++14 -O2 -msse -msse2 -flax-vector-conversions -I"Source" -I"Source\App" -I"%JUCE_PATH%" -I"%JUCE_PATH%\modules" -I"%HISE_PATH%" -I"%HISE_PATH%\hi_core" -I"%HISE_PATH%\hi_modules" -I"%HISE_PATH%\hi_components" -I"%HISE_PATH%\hi_scripting" -I"%HISE_PATH%\hi_backend" -I"%HISE_PATH%\hi_frontend" -D"JUCE_PROJECT_NAME_STRING=\"%project%\"" -DWIN32=1 -DJUCE_SHARED_CODE=1 -DJUCE_GLOBAL_MODULE_SETTINGS_INCLUDED=1 -DJucePlugin_Build_VST=1 -DHI_EXPORT_AS_VST_PLUGIN=1 -DHISE_USE_IPP=0 -DHI_USE_IPP=0 -DHISE_USE_JUCE_FFT=1

:: ����� ������������� �������� ����������� ������ (��� �����������)
set FLG_LOW=-std=c++14 -O0 --param ggc-min-expand=0 --param ggc-min-heapsize=4096 -msse -msse2 -flax-vector-conversions -I"Source" -I"Source\App" -I"%JUCE_PATH%" -I"%JUCE_PATH%\modules" -I"%HISE_PATH%" -I"%HISE_PATH%\hi_core" -I"%HISE_PATH%\hi_modules" -I"%HISE_PATH%\hi_components" -I"%HISE_PATH%\hi_scripting" -I"%HISE_PATH%\hi_backend" -I"%HISE_PATH%\hi_frontend" -D"JUCE_PROJECT_NAME_STRING=\"%project%\"" -DWIN32=1 -DJUCE_SHARED_CODE=1 -DJUCE_GLOBAL_MODULE_SETTINGS_INCLUDED=1 -DJucePlugin_Build_VST=1 -DHI_EXPORT_AS_VST_PLUGIN=1 -DHISE_USE_IPP=0 -DHI_USE_IPP=0 -DHISE_USE_JUCE_FFT=1

echo Processing JUCE core...
g++.exe %FLG% -c "%JUCE_PATH%\modules\juce_core\juce_core.cpp" -o juce_core.o 2>> mingw_error.txt

echo Processing JUCE audio basics...
g++.exe %FLG% -c "%JUCE_PATH%\modules\juce_audio_basics\juce_audio_basics.cpp" -o juce_audio_basics.o 2>> mingw_error.txt

echo Processing JUCE audio processors...
g++.exe %FLG% -c "%JUCE_PATH%\modules\juce_audio_processors\juce_audio_processors.cpp" -o juce_audio_processors.o 2>> mingw_error.txt

echo Processing JUCE audio formats...
g++.exe %FLG% -c "%JUCE_PATH%\modules\juce_audio_formats\juce_audio_formats.cpp" -o juce_audio_formats.o 2>> mingw_error.txt

echo Processing JUCE audio devices...
g++.exe %FLG% -c "%JUCE_PATH%\modules\juce_audio_devices\juce_audio_devices.cpp" -o juce_audio_devices.o 2>> mingw_error.txt

echo Processing JUCE gfx and gui...
g++.exe %FLG% -c "%JUCE_PATH%\modules\juce_graphics\juce_graphics.cpp" -o juce_graphics.o 2>> mingw_error.txt

echo Processing JUCE gui_basics...
g++.exe %FLG% -c "%JUCE_PATH%\modules\juce_gui_basics\juce_gui_basics.cpp" -o juce_gui_basics.o 2>> mingw_error.txt

echo Processing JUCE gui_extra (LOW MEMORY MODE)...
g++.exe %FLG_LOW% -c "%JUCE_PATH%\modules\juce_gui_extra\juce_gui_extra.cpp" -o juce_gui_extra.o 2>> mingw_error.txt

echo Processing JUCE DSP...
g++.exe %FLG% -c "%JUCE_PATH%\modules\juce_dsp\juce_dsp.cpp" -o juce_dsp.o 2>> mingw_error.txt

echo Processing JUCE Events...
g++.exe %FLG% -c "%JUCE_PATH%\modules\juce_events\juce_events.cpp" -o juce_events.o 2>> mingw_error.txt

echo Processing JUCE Data Structures...
g++.exe %FLG% -c "%JUCE_PATH%\modules\juce_data_structures\juce_data_structures.cpp" -o juce_data_structures.o 2>> mingw_error.txt

echo Processing HISE Core (LOW MEMORY MODE)...
g++.exe %FLG_LOW% -c "%HISE_PATH%\hi_core\hi_core.cpp" -o hi_core.o 2>> mingw_error.txt

echo Processing HISE Modules (LOW MEMORY MODE)...
g++.exe %FLG_LOW% -c "%HISE_PATH%\hi_modules\hi_modules.cpp" -o hi_modules.o 2>> mingw_error.txt

echo Processing HISE Components...
g++.exe %FLG% -c "%HISE_PATH%\hi_components\hi_components.cpp" -o hi_components.o 2>> mingw_error.txt

echo Processing HISE Scripting (LOW MEMORY MODE)...
g++.exe %FLG_LOW% -c "%HISE_PATH%\hi_scripting\hi_scripting.cpp" -o hi_scripting.o 2>> mingw_error.txt

echo Processing HISE Frontend (Master File)...
g++.exe %FLG% -c "%HISE_PATH%\hi_frontend\hi_frontend.cpp" -o hi_frontend.o 2>> mingw_error.txt

echo ===================================================
echo   STEP 2: FINAL COUPLING AND LINKING INTO DLL
echo ===================================================
echo Baking your VST2 plugin...

g++.exe -shared -o ..\Hise.dll -Wl,--start-group hi_frontend.o hi_scripting.o hi_components.o hi_modules.o hi_core.o juce_dsp.o juce_audio_processors.o juce_audio_formats.o juce_audio_devices.o juce_audio_basics.o juce_gui_extra.o juce_gui_basics.o juce_graphics.o juce_events.o juce_data_structures.o juce_core.o -Wl,--end-group -lws2_32 -lwininet -lgdi32 -luser32 -lcomdlg32 -lole32 -loleaut32 -luuid -limm32 -lversion -lshlwapi -lwinmm 2>> mingw_error.txt

if exist ..\Hise.dll (
    echo ===================================================
    echo   !!! SUCCESS !!! 32-bit VST2 Hise.dll IS CREATED !
    echo ===================================================
) else (
    echo ===================================================
    echo   LINKING FAILED. CHECK ERRORS BELOW.
    echo ===================================================
    type mingw_error.txt
)
pause